package com.galaxe.sonarQube.model;

import lombok.Data;

@Data
public class History {
	
	public String date;
	public String value;
	
	
	

}
