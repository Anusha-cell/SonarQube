package com.galaxe.sonarQube.model;

public class Constant {

}
