package com.galaxe.sonarQube.model;

import java.util.Date;

import lombok.Data;

@Data
public class DateModel {
	
	private Date startDate;
	private Date endDate;
	
	
	
}
