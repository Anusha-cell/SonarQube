package com.galaxe.sonarQube.model;

import lombok.Data;

@Data
public class ProjectStatus {
	
	private ProjectStatusModel projectStatus;

	

}
