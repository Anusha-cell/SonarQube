package com.galaxe.sonarQube.constant;

public class Constant {
	
	private Constant()
	{}
	
	public static final String USERNAME = "admin";
    public static final String PASSWORD = "admin";

}

